import { Env } from "../bindings/env";

export default class FFI {
  static ident: number;
  static env: Env = new Env();
}
